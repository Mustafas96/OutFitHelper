//
//  PantsViewController.swift
//  Outfit Helper
//
//  Created by Mustafa Sarwar on 5/22/17.
//  Copyright © 2017 Mustafa Sarwar. All rights reserved.
//

import UIKit

class PantsViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    

    @IBOutlet weak var pantImageView: UIImageView!
    
        
        let pants = ["Red","Green","Blue","Orange"]
        
        
        func numberOfComponents(in pickerView: UIPickerView) -> Int{
            return 1
        }
        func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
            return pants[row]
        }
        func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
            return pants.count
        }
        func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
            
            if pants[row] == "Red" {
                pantImageView.image = UIImage(named:"redPant.png")
                Outfit.sharedInstance.addPant(p: "Red")
            }
            else if pants[row] == "Green" {
                pantImageView.image = UIImage(named:"greenPant.jpg")
                Outfit.sharedInstance.addPant(p: "Green")
            }
            else if pants[row] == "Blue" {
                pantImageView.image = UIImage(named:"bluePant.jpeg")
                Outfit.sharedInstance.addPant(p: "Blue")
            }
            else if pants[row] == "Orange" {
                pantImageView.image = UIImage(named:"orangePant.jpeg")
                Outfit.sharedInstance.addPant(p: "Orange")
            }
            
            
        }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

   
}
