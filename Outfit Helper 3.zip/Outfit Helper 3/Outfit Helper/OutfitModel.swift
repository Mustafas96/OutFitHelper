//
//  OutfitModel.swift
//  Outfit Helper
//
//  Created by Mustafa Sarwar on 5/22/17.
//  Copyright © 2017 Mustafa Sarwar. All rights reserved.
//

import Foundation

class Outfit {
    var shiCol:String = ""
    var panCol:String = ""
    var shoCol:String = ""
    
    
    static var sharedInstance = Outfit()
    
    var shirtCol:String {
        return shiCol
    }
    var pantCol:String {
        return panCol
    }
    var shoeCol:String {
        return shoCol
    }
    func addShirt(s: String) {
        shiCol = s
    }
    func addPant(p: String) {
        panCol = p
    }
    func addShoes(o: String) {
        shoCol = o
    }
    
    
}
