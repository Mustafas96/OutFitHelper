//
//  ViewController.swift
//  Outfit Helper
//
//  Created by Mustafa Sarwar on 5/21/17.
//  Copyright © 2017 Mustafa Sarwar. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {

    @IBOutlet weak var ShirtImageView: UIImageView!
    @IBOutlet weak var PantImageView: UIImageView!
    @IBOutlet weak var ShoeImageView: UIImageView!
    
    var a:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Shirt color setter
        if Outfit.sharedInstance.shirtCol == "Red" {
            ShirtImageView.image = UIImage(named:"redShirt.jpeg")
        }
        else if Outfit.sharedInstance.shirtCol == "Green" {
            ShirtImageView.image = UIImage(named:"greenShirt.jpg")
        }
        else if Outfit.sharedInstance.shirtCol == "Blue" {
            ShirtImageView.image = UIImage(named:"blueShirt.jpg")
        }
        else if Outfit.sharedInstance.shirtCol == "Orange" {
            ShirtImageView.image = UIImage(named:"orangeShirt.jpg")
        }
        else {
            print("What?")
        }
        
        
        // Pant color setter
        if Outfit.sharedInstance.pantCol == "Red" {
            PantImageView.image = UIImage(named:"redPant.png")
        }
        else if Outfit.sharedInstance.pantCol == "Green" {
            PantImageView.image = UIImage(named:"greenPant.jpg")
        }
        else if Outfit.sharedInstance.pantCol == "Blue" {
            PantImageView.image = UIImage(named:"bluePant.jpeg")
        }
        else if Outfit.sharedInstance.pantCol == "Orange" {
            PantImageView.image = UIImage(named:"orangePant.jpeg")
        }
        else {
            print("What?")
        }
        
        
        //Shoe color setter
        if Outfit.sharedInstance.shoeCol == "Red" {
            ShoeImageView.image = UIImage(named:"redShoes.jpeg")
        }
        if Outfit.sharedInstance.shoeCol == "Green" {
            ShoeImageView.image = UIImage(named:"greenShoes.jpeg")
        }
        if Outfit.sharedInstance.shoeCol == "Blue" {
            ShoeImageView.image = UIImage(named:"blueShoes.jpeg")
        }
        if Outfit.sharedInstance.shoeCol == "Orange" {
            ShoeImageView.image = UIImage(named:"orangeShoes.jpeg")
        }
        else {
            print("What?")
        }
        
        
        
        




    }

    @IBAction func ShirtUpload(_ sender: AnyObject) {
        a = 1
        
        let shirtImage = UIImagePickerController()
        shirtImage.delegate = self
        
        shirtImage.sourceType = UIImagePickerControllerSourceType.photoLibrary
        
        shirtImage.allowsEditing = false
        
        self.present(shirtImage, animated: false){
        }
    }
    
    @IBAction func PantUpload(_ sender: Any) {
        a = 2
        
        let pantImage = UIImagePickerController()
        pantImage.delegate = self
        
        pantImage.sourceType = UIImagePickerControllerSourceType.photoLibrary
        
        pantImage.allowsEditing = false
        
        self.present(pantImage, animated: false){
        }
    }
    
    @IBAction func ShoeUpload(_ sender: Any) {
        a = 3
        
        let shoeImage = UIImagePickerController()
        shoeImage.delegate = self
        
        shoeImage.sourceType = UIImagePickerControllerSourceType.photoLibrary
        
        shoeImage.allowsEditing = false
        
        self.present(shoeImage, animated: false){
        }
    }
    
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
        {

            if a == 1 {
                let selectedImage = info[UIImagePickerControllerOriginalImage] as! UIImage
                ShirtImageView.image = selectedImage
                self.dismiss(animated: true, completion: nil)
            }
            else if a == 2 {
                let selectedImage = info[UIImagePickerControllerOriginalImage] as! UIImage
                PantImageView.image = selectedImage
                self.dismiss(animated: true, completion: nil)
            }
            else if a == 3 {
                let selectedImage = info[UIImagePickerControllerOriginalImage] as! UIImage
                ShoeImageView.image = selectedImage
                self.dismiss(animated: true, completion: nil)
            }
            else {
                print ("HUH?")
            }
        }
    
 
    
   


}

