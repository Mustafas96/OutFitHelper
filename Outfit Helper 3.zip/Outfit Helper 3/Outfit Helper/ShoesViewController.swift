//
//  ShoesViewController.swift
//  Outfit Helper
//
//  Created by Mustafa Sarwar on 5/22/17.
//  Copyright © 2017 Mustafa Sarwar. All rights reserved.
//

import UIKit

class ShoesViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate  {

        
        
    @IBOutlet weak var shoeImageView: UIImageView!
        
        
        
        let shoes = ["Red","Green","Blue","Orange"]
        
        
        func numberOfComponents(in pickerView: UIPickerView) -> Int{
            return 1
        }
        func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
            return shoes[row]
        }
        func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
            return shoes.count
        }
        func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
            
            if shoes[row] == "Red" {
                shoeImageView.image = UIImage(named:"redShoes.jpeg")
                Outfit.sharedInstance.addShoes(o: "Red")
            }
            else if shoes[row] == "Green" {
                shoeImageView.image = UIImage(named:"greenShoes.jpeg")
                Outfit.sharedInstance.addShoes(o: "Green")
            }
            else if shoes[row] == "Blue" {
                shoeImageView.image = UIImage(named:"blueShoes.jpeg")
                Outfit.sharedInstance.addShoes(o: "Blue")
            }
            else if shoes[row] == "Orange" {
                shoeImageView.image = UIImage(named:"orangeShoes.jpeg")
                Outfit.sharedInstance.addShoes(o: "Orange")
            }
            
        }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
