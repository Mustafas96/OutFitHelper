//
//  ShirtUIViewController.swift
//  Outfit Helper
//
//  Created by Mustafa Sarwar on 5/22/17.
//  Copyright © 2017 Mustafa Sarwar. All rights reserved.
//

import UIKit

class ShirtUIViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    @IBOutlet weak var shirtImageVIew: UIImageView!

    let shirts = ["Red","Green","Blue","Orange"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    
    func numberOfComponents(in pickerView: UIPickerView) -> Int{
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return shirts[row]
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return shirts.count
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
      
        if shirts[row] == "Red" {
        shirtImageVIew.image = UIImage(named:"redShirt.jpeg")
            Outfit.sharedInstance.addShirt(s: "Red")
        }
        else if shirts[row] == "Green" {
            shirtImageVIew.image = UIImage(named:"greenShirt.jpg")
            Outfit.sharedInstance.addShirt(s: "Green")
        }
        else if shirts[row] == "Blue" {
            shirtImageVIew.image = UIImage(named:"blueShirt.jpg")
            Outfit.sharedInstance.addShirt(s: "Blue")
        }
        else if shirts[row] == "Orange" {
            shirtImageVIew.image = UIImage(named:"orangeShirt.jpg")
            Outfit.sharedInstance.addShirt(s: "Orange")
        }

        
        
    }
    
    
    
    
}
